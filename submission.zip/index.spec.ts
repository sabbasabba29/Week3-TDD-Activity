
import { CalculatorModel } from './index';

describe('week4-tdd', (): void => {

  describe('CalculatorModel', (): void => {

    it('CalculatorModel exists', (): void => {

      expect(CalculatorModel).toBeDefined();

    });

  });

});
